package EmployeeSalary;

public class employee {
	
	 //Instance variable : Inside the class but outside the method	
	 //Non-static variables
	 long employeeId;
	 String employeeName;
	 String employeeAddress;
	 long employeePhone;
	 double basicSalary;
	 //static variable
	 static double specialAllowance= 50;
	 static double HRA = 100;
	 	
	public static void main(String[] args) {
		
		//Calling the Constructor1
		//Special method with the same name as class
		employee cons1=new employee(42342,"Michael","USA" ,545365345);
		
		System.out.println (" The ID of employee is :" + (cons1.employeeId));
		System.out.println (" The Name of employee is :" + (cons1.employeeName));
		System.out.println (" The Address of employee is :" + (cons1.employeeAddress));
		System.out.println (" The Phone Number of employee is :" + (cons1.employeePhone));
		
		System.out.println ("--------------------Constructor Overloading ----------------");
		
		//Calling the Constructor2
				employee cons2=new employee(44244,"Rose");
				System.out.println (" The ID of employee is :" + (cons2.employeeId));
				System.out.println (" The Name of employee is :" + (cons2.employeeName));		
			
		// Salary Calculation
		//Salary is a local variable		
			double Salary = SalaryLogic(100000,specialAllowance,HRA);
			System.out.println (" The Special Allowance of employee is :" + specialAllowance);
			System.out.println (" The HRA of employee is :" + HRA);
			System.out.println (" The Salary of employee is :" + Salary);
						
	}
	
	//Constructor method 1 with  4 parameters
	//no static , no return values
	employee(long Id,String Name ,String Address ,long Phone)
	{
		employeeId=Id;
		employeeName=Name;
		employeeAddress=Address;
		employeePhone=Phone;
	}
	
	////Constructor method 2 with  2 parameters
	// Constructor Overloading
	employee(long Id,String Name )
	{
		employeeId=Id;
		employeeName=Name;	
	}
	
	//constructor 3 with  5 parameters
	employee(long Id,String Name ,String Address ,long Phone , double Salary)
	{
		employeeId=Id;
		employeeName=Name;
		employeeAddress=Address;
		employeePhone=Phone;
		basicSalary=Salary;
	}
	
	//static method	with return type
	public static double SalaryLogic(double basicSalary,double specialAllowance , double HRA) { 		
			
		double salary=basicSalary+(basicSalary*specialAllowance/100)+(basicSalary* HRA/100);
		return salary;
	}
	

}


