package EmployeeSalary;

public class InheritanceActivity {

	public static void main(String[] args) {
		

	}

}
