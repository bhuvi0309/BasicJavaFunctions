package EmployeeSalary;

public class Boss extends employee{		

		Boss(long Id, String Name, String Address, long Phone, double Salary) {
		super(Id, Name, Address, Phone, Salary);
		
	}

		public static void main(String[] args) {
				
		//Inheritance from Superclass employee
		//Boss = subclass
			
		Boss obj= new Boss (3452143, " Ashley" , "California" ,7455743 ,6573111);
		System.out.println (" The ID of employee is :" + (obj.employeeId));
		System.out.println (" The Name of employee is :" + (obj.employeeName));
		System.out.println (" The Address of employee is :" + (obj.employeeAddress));
		System.out.println (" The Phone number of employee is :" + (obj.employeePhone));
		System.out.println (" The salary of employee is :" + (obj.basicSalary));
}

}
