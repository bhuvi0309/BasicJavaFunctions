package EmployeeSalary;

public class Trainee extends employee{

	Trainee(long Id, String Name, String Address, long Phone, double Salary) {
		super(Id, Name, Address, Phone, Salary);
			}

	public static void main(String[] args) {
		
		//Inheritance from Superclass employee
		//Trainee = subclass
		
		Trainee obj1= new Trainee (786888, " Sam" , "Ohio" ,45555666 ,234567);
		System.out.println (" The ID of employee is :" + (obj1.employeeId));
		System.out.println (" The Name of employee is :" + (obj1.employeeName));
		System.out.println (" The Address of employee is :" + (obj1.employeeAddress));
		System.out.println (" The Phone number of employee is :" + (obj1.employeePhone));
		System.out.println (" The salary of employee is :" + (obj1.basicSalary));
		
	}

}
