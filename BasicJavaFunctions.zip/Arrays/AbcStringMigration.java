package Arrays;

public class AbcStringMigration {

		public static void main(String[] args) {
			
			String a= "abcdef";
			String b= "xyz1234";
			String c= "abcxy";
			
			//Verify the length of the �a� variable should be greater than the length of the c variable 
			//and should be less than the length of the b variable.
			//len (a)> len( c)
			//len(a)< len (b)
			int lengthOfa = a.length();
			int lengthOfb = b.length();
			int lengthOfc = c.length();
			System.out.println("length of a = " +lengthOfa );
			System.out.println("length of b = " +lengthOfb );
			System.out.println("length of c = " +lengthOfc );

			//Comparing length of a and c
			System.out.println("---------------------------------------");
			System.out.println("----Comparing lengths of String a and String c----");
			if 	(lengthOfa > lengthOfc) 
				{  System.out.println("length of a > length of c");    }	
			else
				{  System.out.println("length of a < length of c ");   }
			
			System.out.println("----Comparing lengths of String a and String b----");
			if 	(lengthOfa < lengthOfb) 
			{  System.out.println("length of a is less than length of b");    }	
			else
			{  System.out.println("length of a is not less than length of b ");   }
			
			
			//�a� variable should not be the same as the �b� variable and �c� variable.
			System.out.println("---------------------------------------");
			System.out.println("----Comparing String a and String b----");
			if (a!=b)
			{  System.out.println("String a is not equal to String b ");    }
			else
			{  System.out.println("String a is same as String b ");   }
			
			System.out.println("----Comparing String a and String c----");
			if (a!=c)
			{  System.out.println("String a is not equal to String c ");    }
			else
			{  System.out.println("String a is same as String c ");   }	
			
			
			//�c� variable should be the same as a variable irrespective of the case.
			System.out.println("---------------------------------------");
			System.out.println("c Variable should remain the same");
			String cUpperCase= c.toUpperCase();
			System.out.println("c Variable upper case value is : "+ cUpperCase );
			//Converting the uppercase value of 'c' variable to lower case to check if it has been modified
			String cLowerCase= cUpperCase.toLowerCase();
			System.out.println("c Variable lower case value after  converting is : "+ cLowerCase );
			
			System.out.println("String c Value : " + c);
			
			//Comparing variable 'c' and cLowerCase variable
			if (c.matches(cLowerCase))
			{  System.out.println("String c is the same after changing to upper case");    }
			else
			{  System.out.println("String c is not the same variable irrespective of the case");   }	
			
					
			//�a� variable should contain cd and should not contain xy.
			System.out.println("---------------------------------------");
			System.out.println("Checking the String characters of a Variable");
			if (a.contains("cd"))
			{  System.out.println("String a contains characters cd");    }
			else
			{  System.out.println("String a does not hold the characters cd"); } 
			
			if (a.contains("xy"))
			{  System.out.println("String a contains characters xy");    }
			else
			{  System.out.println("String a does not hold the characters xy"); } 
			
			
			//Convert the �b� variable into uppercase and verify it should contain �Z� andshould not contains �z�.
			System.out.println("---------------------------------------");
			System.out.println("Checking the String character in the Upper case of b Variable");
				String bUppercase= b.toUpperCase();
				
				System.out.println("Upper case of b Variable : " +bUppercase );
				
				if (bUppercase.contains("Z"))
				{  System.out.println("Upper case of variable b contain the character Z");    }
				else
				{  System.out.println("Upper case of variable b does not contain the character Z"); } 
				
				if (bUppercase.contains("z"))
				{  System.out.println("Upper case of variable b contain the character z");    }
				else
				{  System.out.println("Upper case of variable b does not contain the character z"); } 
				
				//Perform concatenate on �a� and �b� variables 
				//and verify the length is less than the �c� variable�s length or greater than 5.
				System.out.println("---------------------------------------");
				System.out.println("Concatenation of String a and b and its verification");
				
				String aAndb= a.concat(b);
				System.out.println("Concatenation of a and b is" +aAndb);
				int lenaAndb= aAndb.length();
				System.out.println("Length of concatenated String : " +lenaAndb);
				System.out.println("length of c " + lengthOfc);
				if 	(lenaAndb < lengthOfc) 
				{  System.out.println("length of the concatenated String < length of c ");    }	
			else if (lenaAndb > 5)
				{  System.out.println("length of the concatenated String  > 5  ");   }			
				
				//Validate if the �a� variable start with �ab� and the �b� variable should not ends with �yz�.
				System.out.println("---------------------------------------");
				 if (a.startsWith("ab"))
				 {  System.out.println("a variable start with ab");    }
					else
				 {  System.out.println("a variable does not start with ab"); } 
				 
				 System.out.println("length of b = " +lengthOfb );
				 int index= b.indexOf("yz", 0);
					System.out.println("The position where yz starts in b variable is = "+ index );
				  if (index < lengthOfb)
				 {  System.out.println("b variable does not end with yz");    }
					else
				{  System.out.println("b variable does not end with yz"); } 
				
				//Validate if the �c� variable contains space and should not contain9.	
				  System.out.println("---------------------------------------");
				 Boolean whiteSpace= c.matches(" ");
				 System.out.println(" the blank space in c variable is  :" + whiteSpace);
				 if ( c.contains("9"))
				{  System.out.println("c variable contains 9 ");    }
					else
				{  System.out.println("c variable does not contain 9"); } 
				  
					}

		
}
