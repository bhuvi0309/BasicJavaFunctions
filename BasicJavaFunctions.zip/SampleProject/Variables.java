package SampleProject;

public class Variables {

			//Static Variable (Global Variable)
			static int b = 20;
			static String name = "Name";
			
			//Non- Static Variable (Global Variable)
			double c=34.56;
			
	public static void main(String[] args) {
		
			int a=100;//a is local variable which can be accesesd on in main method
			System.out.println(a);
		// to access non-static variable we need to create object
		//ClassName Reference= new ClassName ();
		Variables obj= new Variables();
		// new keyword creates space in memory and the address is loaded to obj.
		//all non static members of the class are loaded in obj
		System.out.println("Non Static variable " + obj.c);
		obj.M2();
		M1();
	}
	
	public static void M1() {
		//global variable accessed outside main method
		System.out.println(b);
		System.out.println(name);
	}
	
	public void M2() {
		System.out.println("Non static method is M2()");
	}
	

}
